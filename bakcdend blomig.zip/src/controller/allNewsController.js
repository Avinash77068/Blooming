import News from "../models/AllNews.js";

export const createNews = async (req, res) => {
  try {
    const { title, description } = req.body;
    const image = req.file ? req.file.filename : null;
    if (!title || !description) {
      return res.status(400).json({
        message: "Title and description are required",
      });
    }
    const news = new News({
      title,
      description,
      image,
    });
    await news.save();
    res.status(201).json({
      message: "News article created successfully",
      news,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error creating news article", error });
  }
};
export const getAllNews = async (req, res) => {
  try {
    const newsArticles = await News.find();
    res.status(200).json(newsArticles);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching news articles", error });
  }
};
export const getNewsById = async (req, res) => {
  try {
    const { id } = req.params;
    const news = await News.findById(id);
    if (!news) {
      return res.status(404).json({ message: "News article not found" });
    }
    res.status(200).json(news);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching news article", error });
  }
};
