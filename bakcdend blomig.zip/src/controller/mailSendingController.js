import nodemailer from "nodemailer";
import dotenv from "dotenv";
import Email from "../models/emailModel.js"; // Import the Email model
dotenv.config();

async function sendMail(to, subject, text, html) {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
    tls: {
      rejectUnauthorized: false, // Disable certificate validation (NOT recommended for production)
    },
  });

  // HTML Email with embedded CSS and an image
  const emailHTML = `
  <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f4f4f4;
          color: #333;
          overflow:hidden;
        }
        .email-container {
          width: 100%;
          max-width: 600px; /* Restrict the max width for larger screens */
          margin: 0 auto;
          background-color: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
          text-align: center;
          color: #333;
        }
        .header img {
          width: 100px;
          height: auto;
          max-width: 100%;
          display: block;
          margin: 0 auto;
        }
        .content {
          margin-top: 15px;
          padding: 5px;
          text-align: justify;
        }
        .content p {
          font-size: 18px;
          color: #555;
          line-height: 1.8;
          margin: 0;
          padding: 0;
        }
        .footer {
          margin-top: 30px;
          text-align: center;
          font-size: 13px;
          color: #888;
        }

        /* Responsive design for smaller screens */
        @media (max-width: 768px) {
          .email-container {
            padding: 15px;
          }
          .header img {
            width: 80px;
          }
          .content p {
            font-size: 16px;
          }
          .footer {
            font-size: 12px;
          }
        }
      </style>
    </head>
    <body>
      <div class="email-container">
        <div class="header">
          <img src="https://yt3.googleusercontent.com/ytc/AIdro_myqpNgTikhBXpzc-UAnxA6uUmFdfmzDwof6e-cH-jS9A=s900-c-k-c0x00ffffff-no-rj" alt="Logo" />
          <h1>${subject}</h1>
        </div>
        <div class="content">
          <p>${text}</p>
        </div>
        <div class="footer">
          <p>&copy; 2025 Blooming Children Academy</p>
        </div>
      </div>
    </body>
  </html>
  `;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    html: emailHTML, // HTML content for rich formatting
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent:", info.messageId);

    // Save email details to the database after sending
    const emailDetails = new Email({
      to,
      subject,
      text,
      html: emailHTML.toString(),
    });

    await emailDetails.save();

    return info;
  } catch (error) {
    console.error("Error sending email:", error);
    throw error;
  }
}

const sendMailHandler = async (req, res) => {
  const { to, subject, text, html } = req.body;

  try {
    const result = await sendMail(to, subject, text, html);
    res.status(200).json({ message: "Mail sent successfully", info: result });
  } catch (error) {
    console.error("Error in sendMail:", error);
    res
      .status(500)
      .json({ error: "Failed to send mail", details: error.message });
  }
};

export default sendMailHandler;
