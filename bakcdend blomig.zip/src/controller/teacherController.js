import Teacher from "../models/teacherModel.js";
export const createTeacher = async (req, res) => {
  try {
    const { name, age, subjects, email, phoneNumber, experience, address } =
      req.body;
    if (
      !name ||
      !age ||
      !subjects ||
      !email ||
      !phoneNumber ||
      !experience ||
      !address
    ) {
      return res.status(400).json({ message: "All fields are required" });
    }
    const existingTeacher = await Teacher.findOne({
      $or: [{ email }, { phoneNumber }],
    });
    if (existingTeacher) {
      return res
        .status(400)
        .json({
          message: "Teacher already exists with the same email or phone number",
        });
    }
    const teacher = new Teacher({
      name,
      age,
      subjects,
      email,
      phoneNumber,
      experience,
      address,
      profilePicture: req.file ? req.file.filename : null, 
    });
    await teacher.save();
    res.status(201).json({ message: "Teacher created successfully", teacher });
  } catch (error) {
    res.status(500).json({ message: "Error creating teacher", error });
  }
};
export const getAllTeachers = async (req, res) => {
  try {
    const teachers = await Teacher.find();
    res.status(200).json(teachers);
  } catch (error) {
    res.status(500).json({ message: "Error fetching teachers", error });
  }
};
export const getTeacherById = async (req, res) => {
  try {
    const { id } = req.params;
    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return res.status(404).json({ message: "Teacher not found" });
    }
    res.status(200).json(teacher);
  } catch (error) {
    res.status(500).json({ message: "Error fetching teacher", error });
  }
};
