import Student from "../models/studentModel.js";
export const createStudent = async (req, res) => {
    try {
      const {
        name,
        age,
        grade,
        subjects,
        email,
        phoneNumber,
     
        fatherName,
        motherName,
        address, // address will be an object containing street, city, state, zipCode
        parentPhoneNumbers, // parentPhoneNumbers will be an object containing fatherPhone and motherPhone
      } = req.body;

      // Check if required fields are provided
      if (
        !name ||
        !age ||
        !grade ||
        !subjects ||
        !email ||
        !phoneNumber ||
        
        !fatherName ||
        !motherName ||
        !address ||
        !parentPhoneNumbers
      ) {
        return res.status(400).json({ message: "All fields are required" });
      }

      // Profile picture is optional, so handle it
      const profilePicture = req.file ? req.file.filename : null;

      // Check if the student already exists based on name, phone number, or email
      const existingStudent = await Student.findOne({
        $or: [{ name }, { phoneNumber }, { email }],
      });

      if (existingStudent) {
        return res.status(400).json({
          message:
            "Student already exists with the same name, phone number, or email",
        });
      } else {
        // Create a new student with all the fields
        const student = new Student({
          name,
          age,
          grade,
          subjects,
          email,
          phoneNumber,
          profilePicture,
        
          fatherName,
          motherName,
          address, // Address object directly passed
          parentPhoneNumbers, // Parent phone numbers object directly passed
        });

        // Save the student to the database
        await student.save();

        // Send success response
        res.status(201).json({
          message: "Student created successfully",
          student,
        });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Error creating student", error });
    }
};
export const getAllStudents = async (req, res) => {
  try
  {
    const students = await Student.find();
    res.status(200).json(students);
  } catch (error)
  {
    res.status(500).json({ message: "Error fetching students", error });
  }
};
export const getStudentById = async (req, res) => {
  try
  {
    const { id } = req.params;
    const student = await Student.findById(id);
    if (!student)
    {
      return res.status(404).json({ message: "Student not found" });
    }
    res.status(200).json(student);
  } catch (error)
  {
    res.status(500).json({ message: "Error fetching student", error });
  }
};
