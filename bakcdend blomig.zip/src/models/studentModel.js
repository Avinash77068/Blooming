import mongoose from "mongoose";

const studentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    age: {
      type: Number,
      required: true,
    },
    grade: {
      type: Number,
      required: true,
    },
    subjects: {
      type: String,
      required: true,
    },
    profilePicture: {
      type: String,
      required: false,
    },
    phoneNumber: {
      type: Number,
      required: true,
    },
    email: {
      type: String,
      required: false,
    },
    fatherName: {
      type: String,
      required: true, // Father's name is mandatory
    },
    motherName: {
      type: String,
      required: true, // Mother's name is mandatory
    },
    address: {
      street: {
        type: String,
        required: true, // Street address is mandatory
      },
      city: {
        type: String,
        required: true, // City is mandatory
      },
      state: {
        type: String,
        required: true, // State is mandatory
      },
      zipCode: {
        type: String,
        required: true, // Zip code is mandatory
      },
    },
    parentPhoneNumbers: {
      fatherPhone: {
        type: Number,
        required: true, // Father's phone number is mandatory
      },
      motherPhone: {
        type: Number,
        required: true, // Mother's phone number is mandatory
      },
    },
  },
  { timestamps: true } // Automatically adds createdAt and updatedAt fields
);

const Student = mongoose.model("Student", studentSchema);

export default Student;
