import mongoose from "mongoose";
const teacherSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    age: {
      type: Number,
      required: true,
    },
    subjects: {
      type: [String], 
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true, 
    },
    phoneNumber: {
      type: Number,
      required: true,
      unique: true, 
    },
    profilePicture: {
      type: String, 
      required: false,
    },
    experience: {
      type: Number, 
      required: true,
    },
    address: {
      street: {
        type: String,
        required: true, 
      },
      city: {
        type: String,
        required: true, 
      },
      state: {
        type: String,
        required: true, 
      },
      zipCode: {
        type: String,
        required: true, 
      },
    },
  },
  { timestamps: true } 
);
const Teacher = mongoose.model("Teacher", teacherSchema);
export default Teacher;
