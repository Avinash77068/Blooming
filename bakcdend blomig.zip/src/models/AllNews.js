import mongoose from "mongoose";

const newsSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true, // Title must be provided
    },
    description: {
      type: String,
      required: true, // Description must be provided
    },
    image: {
      type: String, // URL of the image
      required: false, // Image is optional
    },
   
  },
  { timestamps: true } // Automatically adds createdAt and updatedAt fields
);

const News = mongoose.model("News", newsSchema);

export default News;
