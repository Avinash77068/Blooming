import mongoose from "mongoose";

// Define the schema for email details
const emailSchema = new mongoose.Schema(
  {
    to: {
      type: String,
      required: true,
      trim: true,
    },
    subject: {
      type: String,
      required: true,
      trim: true,
    },
    text: {
      type: String,
      required: true,
    },
    sentAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

// Create a model from the schema
const Email = mongoose.model("Email", emailSchema);

export default Email;
