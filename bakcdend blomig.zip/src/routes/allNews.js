import express from "express";
import multer from "multer";
import path from "path";
import {
  createNews,
  getAllNews,
  getNewsById,
} from "../controller/allNewsController.js";
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "allImage/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage }).single("image");
const router = express.Router();
router.post("/allnews", upload, createNews);
router.get("/allnews", getAllNews);
router.get("/allnews/:id", getNewsById);
export default router;
