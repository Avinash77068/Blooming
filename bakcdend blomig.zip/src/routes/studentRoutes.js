import express from "express";
import multer from "multer";
import path from "path";
import {
  createStudent,
  getAllStudents,
  getStudentById,
} from "../controller/studentController.js";
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "Stuploads/"); 
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); 
  },
});
const upload = multer({ storage }).single("profilePicture");
const router = express.Router();
router.post("/students", upload, createStudent); 
router.get("/students", getAllStudents);
router.get("/students/:id", getStudentById);
export default router;
