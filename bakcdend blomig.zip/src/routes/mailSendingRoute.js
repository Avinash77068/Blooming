import express from "express";
import sendMailHandler from "../controller/mailSendingController.js";
const router = express.Router();
router.post("/send-mail", sendMailHandler);
export default router;
