import express from "express";
import multer from "multer";
import path from "path";
import {
  createTeacher,
  getAllTeachers,
  getTeacherById,
} from "../controller/teacherController.js";
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "teacherUploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage }).single("profilePicture");
const router = express.Router();
router.post("/teacher", upload, createTeacher);
router.get("/teacher", getAllTeachers);
router.get("/teacher/:id", getTeacherById);
export default router;
