// Import necessary modules
import express from "express"; // Express framework for routing and handling HTTP requests
import { config as configDotenv } from "dotenv"; // dotenv package to load environment variables from .env file
import connectDB from "./src/database/db.js"; // Custom function to connect to the MongoDB database
import studentRoutes from "./src/routes/studentRoutes.js"; // Importing routes for student-related operations
import teacherRoutes from "./src/routes/teacherRoutes.js"; // Importing routes for teacher-related operations
import allnews from "./src/routes/allNews.js"; // Importing routes for news-related operations
import sendMails from "./src/routes/mailSendingRoute.js";
import cors from 'cors'
// Load environment variables from .env file
configDotenv();

// Create an Express application instance
const app = express();

// Middle
// ware to parse URL-encoded data (like form submissions)
app.use(express.urlencoded({ extended: true }));

// Middleware to parse JSON data in the request body (for API requests)
app.use(express.json());
app.use(cors()); // Enable Cross-Origin Resource Sharing (CORS) for all routes
// Register route handlers
// Prefix all routes in studentRoutes with "/api"
app.use("/api", studentRoutes);

// Prefix all routes in teacherRoutes with "/api"
app.use("/api", teacherRoutes);

// Prefix all routes in allnews with "/api"
app.use("/api", allnews);

app.use("/api", sendMails);

// Connect to the database
connectDB();

// Define the port for the server (use environment variable if available, otherwise default to 5000)
const PORT = process.env.PORT || 5000;

// Start the server and listen for incoming requests on the specified port

try {
  app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
} catch (error) {
  console.error("Failed to start the server:", error);
}
