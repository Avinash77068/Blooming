export const textWhite="text-white/90"
export const textBlack = "text-black";
export const textBlueType = "text-[#2a8a9d]";