// const isOpen = useSelector((state: any) => state.user.isOpen);
export const bgBlack = "bg-black";
export const bgWhite = "bg-white";
export const BgOther = "bg-[#DCD6D6]";
export const BgBlue = "bg-blue-500";
export const BgGreyFooter = "bg-[#323a3f]";
